package com;
import java.sql.*;

public class UserDao {

	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","123456789");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	public static int save(user u){
		int status=0;
		try{
			Connection con=UserDao.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into ruser values (?,?,?)");
		    System.out.println(u.getName());
		    
			ps.setString(1,u.getName());
			ps.setString(2,u.getEmail());
			ps.setString(3,u.getPassword());
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	
	public static int login(user u){
		//user u=new user();
		int status=0;
		try{
			Connection con=UserDao.getConnection();
			PreparedStatement ps=con.prepareStatement("select password from ruser where name=?");
			ps.setString(1,u.getName());
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
			status=1;
			}
			con.close();
		}
		catch(Exception ex){
		ex.printStackTrace();
		}
		return status;
		
	}

}