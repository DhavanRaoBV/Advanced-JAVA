package dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectorUtility {

	private static Connection con;

	public static Connection getCon() {
		return con;
	}

	static {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe:","system","123456789");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
